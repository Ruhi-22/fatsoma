import scrapy
import json
from pathlib import Path
import pymysql

class FatsomaSpider(scrapy.Spider):
    name = "fatsoma"

    def __init__(self):
        super().__init__()

        # Replace with your MySQL credentials
        self.connection = pymysql.connect(
            host='127.0.0.1',
            user='root',
            password='root',
            database='fatsoma'
        )
        self.cursor = self.connection.cursor()

    def close(self, spider):
        self.cursor.close()
        self.connection.close()

    def start_requests(self):
        urls = [
            "https://fatsoma.com/discover/",
        ]
        for url in urls:
            yield scrapy.Request(url=url, callback=self.parse)

    def parse(self, response):
        # Fetch all JSON data
        json_scripts = response.xpath('//script[@type="application/ld+json"]/text()').getall()
        all_data = [json.loads(script) for script in json_scripts]

        # Save the data in json file
        filename = 'fatson_data.json'
        with open(filename, 'w') as f:
            json.dump(all_data, f, indent=4)
        self.log(f"Saved JSON data to {filename}")

        # Extract pagination links
      

       # Process and insert data into MySQL
        self.process_and_insert_data(all_data)

    def process_and_insert_data(self, data):
        # Extract relevant data from each item in 'data'
        # Modify this logic to match your table structure and data format
        for item in data:
            # Example extraction (replace with your actual keys)
            name = item.get('name')
            #description = item.get('description')
            start_date = item.get('startDate')
            end_date = item.get('endDate')
            age_restriction = item.get('typicalAgeRange')

            # Construct and execute INSERT query
            sql = "INSERT INTO events (name, start_date, end_date, age_restriction) VALUES (%s, %s, %s, %s)"
            values = (name, start_date, end_date,age_restriction)
            try:
                self.cursor.execute(sql, values)
                self.connection.commit()
            except Exception as e:
                self.log(f"Error inserting data: {e}")

